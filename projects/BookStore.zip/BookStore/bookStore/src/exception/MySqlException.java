package exception;

public class MySqlException extends Exception {
    public MySqlException(String message){
        super(message);
    }
}
