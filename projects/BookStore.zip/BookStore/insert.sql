﻿use bookStore2;
delete from products;



insert into products(id,name,category,price,pnum,imgurl) values("1","算法导论","计算机","25",100,"/bookcover/101.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("2","java","计算机","25",100,"/bookcover/103.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("3","java虚拟机","计算机","25",100,"/bookcover/104.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("4","算法","计算机","25",100,"/bookcover/105.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("5","数据结构","计算机","25",100,"/bookcover/101.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("6","爵迹","文学","25",100,"/bookcover/101.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("7","爵士唐门","文学","25",100,"/bookcover/103.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("8","绝世唐门","文学","25",100,"/bookcover/104.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("9","斗罗大陆","文学","25",100,"/bookcover/105.jpg");
insert into products(id,name,category,price,pnum,imgurl) values("10","斗破苍穹","文学","25",100,"/bookcover/101.jpg");
