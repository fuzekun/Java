package com.fuzekun.niukeP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NiukePApplication {

	public static void main(String[] args) {
		SpringApplication.run(NiukePApplication.class, args);
	}

}
