package com.fuzekun.niukeP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NiukePApplicationTests {

	@Test
	void contextLoads() {
	}

}
